package com.example.travel_mate_v1;

class OtherActivity {


}
